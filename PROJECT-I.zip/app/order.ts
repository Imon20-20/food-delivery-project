export class Order {
    constructor (
        public orderId: number,

        public total: number
    )
    {

    }
}