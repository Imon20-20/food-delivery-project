import { Component } from '@angular/core';
import { Payment } from '../payment';
import { PaymentService } from '../payment.service';
import { ActivatedRoute,Router } from '@angular/router';

@Component({
  selector: 'app-payment-controller',
  templateUrl: './payment-controller.component.html',
  styleUrls: ['./payment-controller.component.css']
})
export class PaymentControllerComponent {
  payment: Payment = new Payment (0,"","",0,"",0,"");
  //cartList:any;
  orderId:number=0;
   userEmailId:string="";
   constructor(private paymentService: PaymentService, private activatedRoute:ActivatedRoute,private router:Router) {}
   ngOnInit(): void {
     this.orderId = this.activatedRoute.snapshot.params["orderId"];
     this.userEmailId = this.activatedRoute.snapshot.params["userEmailId"];
     //console.log("inside OnInit")
    // let res = this.cartService.getAllCart();
   // res.subscribe((data:any) => this.cartList = data );
    }

     confirm() {
    console.log("buttonclick");
    console.log(this.payment);
    let res=this.paymentService.addPayment(this.payment,this.orderId,this.userEmailId).subscribe((data:any)=> {console.log ("added")},
    error=>console.log(error));
    console.log(res);
    this.router.navigate(['/paymentdetails',this.userEmailId]);
   }
}
