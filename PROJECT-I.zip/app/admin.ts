export class Admin {
    constructor(
        public adminId: number,

        public firstName: string,

        public lastName: string,

        public adminEmailId: string,
        
        public adminPassword: string

    ) {

    }
}