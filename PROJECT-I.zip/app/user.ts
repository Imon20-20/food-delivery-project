export class User {
    constructor(
        public emailId:string,
        public password:string,
        public firstName: string,
        
        public lastName:string,
        public role:string,
        public mobileNo:string,
        public street:string,
        public district:string,
        public state:string,
        public zipCode:string,

            )        {

        }
}