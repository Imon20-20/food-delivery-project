import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Payment } from './payment';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  constructor(private http: HttpClient) {

   }
   private url = "http://localhost:8089/api/cart";

   public addPayment(payment:Payment, orderId:number,userEmailId:string): Observable<any>{
    console.log("AddPaymentservice");
    console.log(payment);
    console.log("orderId"+orderId);
     return this.http.post<any>("http://localhost:8089/api/payment/add/"+orderId+"/"+userEmailId,payment,{responseType:'Text' as 'json'});
   }
   
   public getAllPaymentByUserEmailId(userEmailId:string){
    console.log("inside Payment Service");
    return this.http.get("http://localhost:8089/api/payment/user/"+userEmailId);
   }

   public delete(paymentId:number) {
    console.log("inside Payment Service");
    return this.http.delete("http://localhost:8089/api/payment/"+paymentId,{responseType:'Text' as 'json'} );
   }
   public getPaymentBypaymentId(paymentId:number) {
    console.log("get Food By CategoryId Service");
    return this.http.get("http://localhost:8089/api/payment/"+paymentId);
   }
}
 